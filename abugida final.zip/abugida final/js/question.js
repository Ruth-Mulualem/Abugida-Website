function displayRadioValue() { 

   

                document.getElementById("result").innerHTML 

                        ='1. ሚ'+"<br>" + '2. ሳ'+"<br>"+ '3. ዱ'+"<br>"+'4. ጌ'; 

        } 

     



function displayAnswer() { 

    document.getElementById("answer").innerHTML = "a. 7" + "<br>" + "b. 15" + "<br>" + "c. 10" +
    "<br>" + "d. 4" + "<br>" + "e. 4" + "<br>" + "f. 13"; 

    
    }
    function displaycheckAnswer() { 

        document.getElementById("anscheck").innerHTML = "Letter: 'A' " + "<br>" + "Nouns: Bus, Pen, Chair, Table" + "<br>" + "Pronouns: I, They, He, We" +
        "<br>" + "Verbs: Cut, Sleep"; 
    
        
        }

