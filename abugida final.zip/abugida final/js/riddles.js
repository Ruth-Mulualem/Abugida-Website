function displayRiddleAns() { 

    document.getElementById("ans").innerHTML = ""; 

    var ele = document.getElementsByTagName('input'); 

      

    for(i = 0; i < ele.length; i++) { 

          

        if(ele[i].type="radio") { 

          

            if(ele[i].checked) 

                document.getElementById("ans").innerHTML 

                        ='1. ዶሮ'+"<br>" + '2. ጤዛ'+"<br>"+ '3. ሰው'+"<br>"+'4. መስታወት' + "<br>" + '5. ባቄላ' +
                        "<br>" + '6. አልጋ' + "<br>" + '7. ጀበና እና ሲኒ'; 

        } 

    } 

} 
